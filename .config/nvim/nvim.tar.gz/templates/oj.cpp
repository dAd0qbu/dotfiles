#include <iostream>
#define ll long long
#define II pair<int,int>
#define FOR(i, k, n) for(ll i=(k);(k)<(n)?i<(n):i>(n);(k)<(n)?i+=1:i-=1)
using namespace std;

int main() {
    cin.sync_with_stdio(0);
    cin.tie(0);
    freopen("", "r", stdin);    
    freopen("", "w", stdout);    
     


    return 0;
}
