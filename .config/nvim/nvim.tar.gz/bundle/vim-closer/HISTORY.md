## v0.2.0
> Sep 28, 2015

* JavaScript: add semicolons in the file when `'use strict';` is found.

## v0.1.2
> Jun 19, 2015

* Hotfix to actually make the last version's change work.

## v0.1.1
> Jun 19, 2015

* Prevent semicolons in if/else in JavaScript.

## v0.1.0
> Jun  3, 2015

* Initial release.
