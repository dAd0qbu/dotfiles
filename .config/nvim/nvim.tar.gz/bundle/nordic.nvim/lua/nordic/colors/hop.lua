-- 'phaazon/hop.nvim'
return function(c)
    return {
        { 'HopNextKey', c.cyan },
        { 'HopNextKey1', c.bright_cyan },
        { 'HopNextKey2', c.blue },
        { 'HopUnmatched', c.gray },
    }
end
