-- 'haringsrob/nvim_context_vt'
return function(c, s, cs)
    return {
        { 'ContextVt', c.gray, c.none },
    }
end
