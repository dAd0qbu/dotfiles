-- 'simrat39/symbols-outline.nvim'
return function(c, s)
    return {
        { 'FocusedSymbol', c.yellow, c.none, s.bold },
    }
end
