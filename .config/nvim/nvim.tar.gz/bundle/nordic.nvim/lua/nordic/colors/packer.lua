-- 'wbthomason/packer.nvim'
return function(c)
    return {
        { 'packerHash', c.grayish, c.none },
        { 'packerStatusSuccess', c.green, c.none },
    }
end
