-- 'vhyrro/neorg'
return function(c)
    return {
        { 'Conceal', c.none },
    }
end
