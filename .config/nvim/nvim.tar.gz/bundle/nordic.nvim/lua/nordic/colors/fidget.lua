-- 'j-hui/fidget.nvim'
return function(c, s, cs)
    return {
        { 'FidgetTitle', c.white, c.none },
        { 'FidgetTask', c.intense_blue, c.none },
    }
end
