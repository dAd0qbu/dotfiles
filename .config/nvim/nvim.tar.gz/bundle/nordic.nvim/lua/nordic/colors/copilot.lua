-- 'github/copilot.vim'
return function(c, s, cs)
    return {
        { 'CopilotSuggestion', c.gray, c.none },
    }
end
