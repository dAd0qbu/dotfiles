-- 'vimwiki/vimwiki'
return function(c)
    return {
        { 'VimwikiHeader1', c.bright_cyan },
        { 'VimwikiHeader2', c.blue },
        { 'VimwikiHeader3', c.purple },
    }
end
