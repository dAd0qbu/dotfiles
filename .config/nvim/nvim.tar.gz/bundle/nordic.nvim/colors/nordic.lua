local nordic = require('nordic')
nordic.colorscheme({})
